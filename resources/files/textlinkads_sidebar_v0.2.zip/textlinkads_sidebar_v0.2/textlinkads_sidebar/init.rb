require 'sidebar'
require 'textlinkads_sidebar'

TextlinkadsSidebar.view_root = File.dirname(__FILE__) + '/views'

