require 'cgi'

class TextlinkadsSidebar < Sidebar
  display_name "Text Link Ads Sidebar"
  description 'Text Link Ads from <a href="http://www.text-link-ads.com">text-link-ads.com</a>'

  setting :title, 'Recommended Sites'
	setting :key, ''
	setting :affiliate_id, '', :label => 'Affiliate ID'
	setting :advertise_here, '', :label => 'Advertise Here'


  lifetime 6.hours

  def textlinkads
		@textlinkads ||= Textlinkads.new(key, title, affiliate_id, advertise_here)
		rescue Exception => e
			logger.info(e)
		nil
  end

end
