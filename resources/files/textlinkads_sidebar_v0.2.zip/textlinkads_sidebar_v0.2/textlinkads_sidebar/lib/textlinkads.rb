#copyright 2007 Fabio Cevasco

require 'net/http'
require 'cgi'

class Textlinkads
	attr_accessor :key, :title, :links, :affiliate_id, :advertise_here

	def initialize(key, title, affiliate_id, advertise_here, refresh = true)
		self.key = key
		self.title = title
		self.affiliate_id = affiliate_id
		self.advertise_here = advertise_here
		self.links = {}
		self.refresh if refresh
  end
	
	def refresh
    url = "http://www.text-link-ads.com/xml.php?inventory_key="+@key
    self.links = requestlinks(url) rescue nil
  end
	
	private
  
  def requestlinks(url)
    XmlSimple.xml_in(http_get(url))
  end

  # Does an HTTP GET on a given URL and returns the response body
  def http_get(url)
    Net::HTTP.get_response(URI.parse(url)).body.to_s
  end
end
